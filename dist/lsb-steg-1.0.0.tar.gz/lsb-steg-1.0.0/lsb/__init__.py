from . import endetext
