from setuptools import setup

setup(name="lsb-steg",
      version="1.0.0",
      description="LSB Steganography for text",
      packages=["lsb"], py_modules=["test"],
      author="Euler0525",
      author_email="13804800525@139.com")
